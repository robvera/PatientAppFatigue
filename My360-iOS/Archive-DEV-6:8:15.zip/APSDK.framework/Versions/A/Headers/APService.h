//
//  APService.h
//  AnyPresence SDK
//

/*!
 @header APService
 @abstract APService class
 */

#import <Foundation/Foundation.h>

/*!
 @class APService
 @abstract Abstract base class for generated data sources.
 */

@interface APService : NSObject

@end
