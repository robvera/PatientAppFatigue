//
//  PatientApp$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientApp$AP$.h"

@implementation PatientApp$AP$

@dynamic id;
@dynamic appId;
@dynamic patientId;
@dynamic patient;

@end
