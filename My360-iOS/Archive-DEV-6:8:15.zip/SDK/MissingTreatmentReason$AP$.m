//
//  MissingTreatmentReason$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "MissingTreatmentReason$AP$.h"

@implementation MissingTreatmentReason$AP$

@dynamic id;
@dynamic inactive;
@dynamic name;
@dynamic patientAdherenceLog;

@end
