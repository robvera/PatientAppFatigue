//
//  APKeyedArchiverTransformer.h
//  AnyPresence SDK
//

#import <Foundation/Foundation.h>

@interface APKeyedArchiverTransformer : NSValueTransformer

@end
