//
//  PatientExacerbation$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientExacerbation$AP$.h"

@implementation PatientExacerbation$AP$

@dynamic id;
@dynamic appId;
@dynamic archived;
@dynamic concurrentInfection;
@dynamic endOn;
@dynamic fatigability;
@dynamic heatExposure;
@dynamic intensity;
@dynamic patientId;
@dynamic startOn;
@dynamic stress;
@dynamic symptomDenormalized;
@dynamic symptomId;
@dynamic symptom;

@end
