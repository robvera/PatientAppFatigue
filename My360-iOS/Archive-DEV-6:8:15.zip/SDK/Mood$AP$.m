//
//  Mood$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "Mood$AP$.h"

@implementation Mood$AP$

@dynamic id;
@dynamic inactive;
@dynamic name;
@dynamic patientJournals;

@end
