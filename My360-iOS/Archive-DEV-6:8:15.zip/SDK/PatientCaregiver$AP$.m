//
//  PatientCaregiver$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientCaregiver$AP$.h"

@implementation PatientCaregiver$AP$

@dynamic id;
@dynamic email;
@dynamic emailNotifications;
@dynamic name;
@dynamic patientId;
@dynamic phone;
@dynamic smsNotifications;
@dynamic patient;

@end
