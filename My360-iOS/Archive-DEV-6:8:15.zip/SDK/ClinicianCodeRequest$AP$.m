//
//  ClinicianCodeRequest$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "ClinicianCodeRequest$AP$.h"

@implementation ClinicianCodeRequest$AP$

@dynamic id;
@dynamic dateRequested;
@dynamic emailAddress;
@dynamic fax;
@dynamic firstName;
@dynamic lastName;
@dynamic patientId;
@dynamic phone;
@dynamic sendEmailFlag;
@dynamic statusFlag;
@dynamic patient;

@end
