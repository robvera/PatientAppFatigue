//
//  EducationalReading$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "EducationalReading$AP$.h"

@implementation EducationalReading$AP$

@dynamic id;
@dynamic addedOn;
@dynamic appId;
@dynamic clinicianId;
@dynamic defaultEducation;
@dynamic desc;
@dynamic inactive;
@dynamic name;
@dynamic url;
@dynamic patientEducations;
@dynamic clinician;

@end
