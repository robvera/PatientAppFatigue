//
//  PatientAsthmaActionMedication$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientAsthmaActionMedication$AP$.h"

@implementation PatientAsthmaActionMedication$AP$

@dynamic id;
@dynamic appId;
@dynamic dose;
@dynamic frequency;
@dynamic medication;
@dynamic medicationType;
@dynamic patientAsthmaActionIdSeq;
@dynamic patientAsthmaId;
@dynamic patientId;
@dynamic postedDate;
@dynamic patientAsthma;

@end
