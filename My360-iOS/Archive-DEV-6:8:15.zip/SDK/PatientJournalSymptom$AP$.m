//
//  PatientJournalSymptom$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientJournalSymptom$AP$.h"

@implementation PatientJournalSymptom$AP$

@dynamic id;
@dynamic patientJournalId;
@dynamic symptomId;
@dynamic patientJournal;
@dynamic symptom;

@end
