//
//  IngestionMethod$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "IngestionMethod$AP$.h"

@implementation IngestionMethod$AP$

@dynamic id;
@dynamic inactive;
@dynamic name;
@dynamic patientTreatments;

@end
