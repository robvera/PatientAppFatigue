//
//  Chart$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "Chart$AP$.h"

@implementation Chart$AP$

@dynamic id;
@dynamic chartdata;
@dynamic chartName;

@end
