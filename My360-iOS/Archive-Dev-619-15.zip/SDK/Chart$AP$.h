//
//  Chart$AP$.h
//  AnyPresence SDK
//

#import "APInternalObject.h"
#import "Typedefs.h"

@interface Chart$AP$ : APInternalObject

@property (nonatomic, strong) NSNumber * id;
@property (nonatomic, strong) NSDictionary * chartdata;
@property (nonatomic, strong) NSString * chartName;

@end
