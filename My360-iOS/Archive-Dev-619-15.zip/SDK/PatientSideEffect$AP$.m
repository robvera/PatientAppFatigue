//
//  PatientSideEffect$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientSideEffect$AP$.h"

@implementation PatientSideEffect$AP$

@dynamic id;
@dynamic appId;
@dynamic archived;
@dynamic medicationIds;
@dynamic medicationUnsure;
@dynamic patientId;
@dynamic sideEffectDenormalized;
@dynamic sideEffectId;
@dynamic sideEffectOn;
@dynamic patientSideEffectMedications;
@dynamic sideEffect;

@end
