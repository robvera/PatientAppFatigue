//
//  PatientFatigueAnswer$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientFatigueAnswer$AP$.h"

@implementation PatientFatigueAnswer$AP$

@dynamic id;
@dynamic answer;
@dynamic patientFatigueResultId;
@dynamic question;
@dynamic sortId;
@dynamic subscale;
@dynamic patientFatigueResult;

@end
