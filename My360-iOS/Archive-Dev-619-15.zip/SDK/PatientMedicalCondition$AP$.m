//
//  PatientMedicalCondition$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientMedicalCondition$AP$.h"

@implementation PatientMedicalCondition$AP$

@dynamic id;
@dynamic medicalConditionDenormalized;
@dynamic medicalConditionId;
@dynamic medicalConditionIds;
@dynamic patientId;
@dynamic medicalCondition;

@end
