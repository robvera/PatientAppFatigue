//
//  PatientEducation$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientEducation$AP$.h"

@implementation PatientEducation$AP$

@dynamic id;
@dynamic appId;
@dynamic archived;
@dynamic educationalReadingDenormalized;
@dynamic educationalReadingId;
@dynamic educationalReadingUrl;
@dynamic favorite;
@dynamic patientId;
@dynamic unread;
@dynamic educationalReading;

@end
