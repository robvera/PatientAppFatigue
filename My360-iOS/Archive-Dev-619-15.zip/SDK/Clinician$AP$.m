//
//  Clinician$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "Clinician$AP$.h"

@implementation Clinician$AP$

@dynamic id;
@dynamic clinicianType;
@dynamic couponCode;
@dynamic email;
@dynamic firstName;
@dynamic lastName;
@dynamic patientClinicians;
@dynamic educationalReadings;

@end
