//
//  DosageUom$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "DosageUom$AP$.h"

@implementation DosageUom$AP$

@dynamic id;
@dynamic dosageCat;
@dynamic inactive;
@dynamic name;
@dynamic patientTreatments;

@end
