//
//  PatientSideEffectMedication$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientSideEffectMedication$AP$.h"

@implementation PatientSideEffectMedication$AP$

@dynamic id;
@dynamic medicationId;
@dynamic patientSideEffectId;
@dynamic medication;
@dynamic patientSideEffect;

@end
