//
//  ApplicationQuestionnaire$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "ApplicationQuestionnaire$AP$.h"

@implementation ApplicationQuestionnaire$AP$

@dynamic id;
@dynamic appId;
@dynamic columnEight;
@dynamic columnEighteen;
@dynamic columnEleven;
@dynamic columnFifteen;
@dynamic columnFive;
@dynamic columnFour;
@dynamic columnFourteen;
@dynamic columnNine;
@dynamic columnNineteen;
@dynamic columnOne;
@dynamic columnSeven;
@dynamic columnSeventeen;
@dynamic columnSix;
@dynamic columnSixteen;
@dynamic columnTen;
@dynamic columnThirteen;
@dynamic columnThree;
@dynamic columnTwelve;
@dynamic columnTwenty;
@dynamic columnTwentyfive;
@dynamic columnTwentyfour;
@dynamic columnTwentyone;
@dynamic columnTwentythree;
@dynamic columnTwentytwo;
@dynamic columnTwo;
@dynamic isActive;

@end
