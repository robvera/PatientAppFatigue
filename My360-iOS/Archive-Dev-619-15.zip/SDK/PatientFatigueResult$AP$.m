//
//  PatientFatigueResult$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientFatigueResult$AP$.h"

@implementation PatientFatigueResult$AP$

@dynamic id;
@dynamic archived;
@dynamic cognitiveSubscale;
@dynamic completedOn;
@dynamic createdOn;
@dynamic isCompleted;
@dynamic patientId;
@dynamic physicalSubscale;
@dynamic psychosocialSubscale;
@dynamic patientFatigueAnswers;

@end
