//
//  Application$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "Application$AP$.h"

@implementation Application$AP$

@dynamic id;
@dynamic androidAppVersion;
@dynamic appName;
@dynamic appVersion;
@dynamic downloadUrl;
@dynamic settings;

@end
