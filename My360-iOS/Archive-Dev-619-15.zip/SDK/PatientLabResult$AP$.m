//
//  PatientLabResult$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "PatientLabResult$AP$.h"

@implementation PatientLabResult$AP$

@dynamic id;
@dynamic appId;
@dynamic archived;
@dynamic clinicianOffice;
@dynamic hospital;
@dynamic labResultOn;
@dynamic labResultStatDenormalized;
@dynamic labResultStatId;
@dynamic patientId;
@dynamic testTypeDenormalized;
@dynamic testTypeId;
@dynamic labResultStat;
@dynamic testType;

@end
