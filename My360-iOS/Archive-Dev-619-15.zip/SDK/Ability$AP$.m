//
//  Ability$AP$.m
//  AnyPresence SDK
//

#import "APObject+Remote.h"
#import "APObject+Local.h"
#import "APObject+RemoteConfig.h"
#import "APObjectRemoteConfig.h"
#import "Ability$AP$.h"

@implementation Ability$AP$

@dynamic id;
@dynamic appId;
@dynamic inactive;
@dynamic name;
@dynamic summary;
@dynamic patientJournals;

@end
