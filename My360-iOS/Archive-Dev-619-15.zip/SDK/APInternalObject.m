//
//  APInternalObject.m
//  AnyPresence SDK
//

#import "APContext.h"
#import "APInternalObject.h"

@implementation APInternalObject

@dynamic currentCredentialsContext;

@end
